﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UsingAnAPI___Bono
{
    public partial class Trivia : Form
    {
        string theAnswer;

        public Trivia()
        {
            InitializeComponent();
        }

        private void Trivia_Load(object sender, EventArgs e)
        {
            string jsonTriviaData;

            using (var web = new WebClient())
            {
                String url = "https://opentdb.com/api.php?amount=1";
                jsonTriviaData = web.DownloadString(url);
            }
            
            dynamic jsonObj = JValue.Parse(jsonTriviaData);

            string type = jsonObj.results[0].type;
            string option1, option2, option3, option4;

            theAnswer = jsonObj.results[0].correct_answer;
            option1 = jsonObj.results[0].correct_answer;
            option2 = jsonObj.results[0].incorrect_answers[0];

            txtQuestion.Text = jsonObj.results[0].question;          
            radOne.Text = option1;
            radTwo.Text = option2;

            if (type == "boolean")
            {
                radThree.Visible = false;
                radFour.Visible = false;
            }
            else
            {
                option3 = jsonObj.results[0].incorrect_answers[1];
                option4 = jsonObj.results[0].incorrect_answers[2];

                radThree.Text = option3;
                radFour.Text = option4;

                radThree.Visible = true;
                radFour.Visible = true;
            }

                //lblAnswer.Text = jsonObj.results[0].correct_answer;
        }

        private void btnAnother_Click(object sender, EventArgs e)
        {
            if(radOne.Checked == true)
            {
                if (radOne.Text == theAnswer)
                {
                    MessageBox.Show("That's Correct");
                }
                else
                {
                    MessageBox.Show("That's Incorrect\nThe Correct Answer is: " + theAnswer);
                }
            }
            else if(radTwo.Checked == true)
            {
                if (radTwo.Text == theAnswer)
                {
                    MessageBox.Show("That's Correct");
                }
                else
                {
                    MessageBox.Show("That's Incorrect\nThe Correct Answer is: " + theAnswer);
                }
            }
            else if(radThree.Checked == true)
            {
                if (radThree.Text == theAnswer)
                {
                    MessageBox.Show("That's Correct");
                }
                else
                {
                    MessageBox.Show("That's Incorrect\nThe Correct Answer is: " + theAnswer);
                }
            }
            else
            {
                if (radFour.Text == theAnswer)
                {
                    MessageBox.Show("That's Correct");
                }
                else
                {
                    MessageBox.Show("That's Incorrect\nThe Correct Answer is: " + theAnswer);
                }
            }

            if(MessageBox.Show("Would you like another trivia question?", 
                "Another Question?", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                string jsonTriviaData;

                using (var web = new WebClient())
                {
                    String url = "https://opentdb.com/api.php?amount=1";
                    jsonTriviaData = web.DownloadString(url);
                }

                dynamic jsonObj = JValue.Parse(jsonTriviaData);

                string type = jsonObj.results[0].type;
                string option1, option2, option3, option4;

                theAnswer = jsonObj.results[0].correct_answer;
                option1 = jsonObj.results[0].correct_answer;
                option2 = jsonObj.results[0].incorrect_answers[0];

                txtQuestion.Text = jsonObj.results[0].question;
                radOne.Text = option1;
                radTwo.Text = option2;

                if (type == "boolean")
                {
                    radThree.Visible = false;
                    radFour.Visible = false;
                }
                else
                {
                    option3 = jsonObj.results[0].incorrect_answers[1];
                    option4 = jsonObj.results[0].incorrect_answers[2];

                    radThree.Text = option3;
                    radFour.Text = option4;

                    radThree.Visible = true;
                    radFour.Visible = true;
                }
            }
            else
            {
                MessageBox.Show("Well Okay Then");
                this.Close();
            }
        }
    }
}

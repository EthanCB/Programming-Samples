﻿namespace UsingAnAPI___Bono
{
    partial class Trivia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCheck = new System.Windows.Forms.Button();
            this.txtQuestion = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radOne = new System.Windows.Forms.RadioButton();
            this.radTwo = new System.Windows.Forms.RadioButton();
            this.radThree = new System.Windows.Forms.RadioButton();
            this.radFour = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCheck
            // 
            this.btnCheck.Location = new System.Drawing.Point(125, 455);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(121, 36);
            this.btnCheck.TabIndex = 2;
            this.btnCheck.Text = "Check Answer";
            this.btnCheck.UseVisualStyleBackColor = true;
            this.btnCheck.Click += new System.EventHandler(this.btnAnother_Click);
            // 
            // txtQuestion
            // 
            this.txtQuestion.Location = new System.Drawing.Point(15, 13);
            this.txtQuestion.Multiline = true;
            this.txtQuestion.Name = "txtQuestion";
            this.txtQuestion.Size = new System.Drawing.Size(352, 160);
            this.txtQuestion.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radFour);
            this.groupBox1.Controls.Add(this.radThree);
            this.groupBox1.Controls.Add(this.radTwo);
            this.groupBox1.Controls.Add(this.radOne);
            this.groupBox1.Location = new System.Drawing.Point(91, 192);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 238);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            // 
            // radOne
            // 
            this.radOne.AutoSize = true;
            this.radOne.Location = new System.Drawing.Point(45, 38);
            this.radOne.Name = "radOne";
            this.radOne.Size = new System.Drawing.Size(110, 21);
            this.radOne.TabIndex = 0;
            this.radOne.TabStop = true;
            this.radOne.Text = "radioButton1";
            this.radOne.UseVisualStyleBackColor = true;
            // 
            // radTwo
            // 
            this.radTwo.AutoSize = true;
            this.radTwo.Location = new System.Drawing.Point(45, 85);
            this.radTwo.Name = "radTwo";
            this.radTwo.Size = new System.Drawing.Size(110, 21);
            this.radTwo.TabIndex = 1;
            this.radTwo.TabStop = true;
            this.radTwo.Text = "radioButton2";
            this.radTwo.UseVisualStyleBackColor = true;
            // 
            // radThree
            // 
            this.radThree.AutoSize = true;
            this.radThree.Location = new System.Drawing.Point(45, 132);
            this.radThree.Name = "radThree";
            this.radThree.Size = new System.Drawing.Size(110, 21);
            this.radThree.TabIndex = 2;
            this.radThree.TabStop = true;
            this.radThree.Text = "radioButton3";
            this.radThree.UseVisualStyleBackColor = true;
            // 
            // radFour
            // 
            this.radFour.AutoSize = true;
            this.radFour.Location = new System.Drawing.Point(46, 179);
            this.radFour.Name = "radFour";
            this.radFour.Size = new System.Drawing.Size(110, 21);
            this.radFour.TabIndex = 3;
            this.radFour.TabStop = true;
            this.radFour.Text = "radioButton4";
            this.radFour.UseVisualStyleBackColor = true;
            // 
            // Trivia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(383, 525);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtQuestion);
            this.Controls.Add(this.btnCheck);
            this.Name = "Trivia";
            this.Text = "Trivia";
            this.Load += new System.EventHandler(this.Trivia_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.TextBox txtQuestion;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radFour;
        private System.Windows.Forms.RadioButton radThree;
        private System.Windows.Forms.RadioButton radTwo;
        private System.Windows.Forms.RadioButton radOne;
    }
}
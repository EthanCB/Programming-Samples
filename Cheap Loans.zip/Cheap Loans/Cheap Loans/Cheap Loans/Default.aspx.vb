﻿' Name:                 Cheap Loans
' Purpose:              Calculates a Loan
' Created by:   Ethan Bono on 12/11/2017

Option Explicit On
Option Strict On
Option Infer Off

Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        'Dim amt As Double
        'Dim rate As Double
        'Dim term As Double

        'Dim validAmt As Boolean
        'Dim validRate As Boolean
        'Dim validTerm As Boolean
        lblError.Text = ""

        Try
            Dim newLoan As Loan =
                New Loan(txtName.Text.Trim, txtAmount.Text.Trim, txtRate.Text.Trim, txtTerm.Text.Trim)

            lblError.ForeColor = Drawing.Color.Green
            lblError.Text = newLoan.Name & ", your monthly payerments are " & calcPmt(newLoan).ToString("C")

            SqlDataSource.InsertParameters.Add("Name", newLoan.Name)
            SqlDataSource.InsertParameters.Add("Amt", newLoan.AmtStr)
            SqlDataSource.InsertParameters.Add("Rate", newLoan.RateStr)
            SqlDataSource.InsertParameters.Add("Term", newLoan.TermStr)
            SqlDataSource.Insert()

        Catch nne As NullNameException
            lblError.ForeColor = Drawing.Color.Red
            lblError.Text = "Name is Required"
        Catch ine As InvalidNameException
            lblError.ForeColor = Drawing.Color.Red
            lblError.Text = "Name Cannot Have More than 25 Character"
        Catch nae As NullAmtException
            lblError.ForeColor = Drawing.Color.Red
            lblError.Text = "Amount is Required"
        Catch nnae As NonNumericAmtException
            lblError.ForeColor = Drawing.Color.Red
            lblError.Text = "Amount Must be Numeric"
        Catch iae As InvalidAmtException
            lblError.ForeColor = Drawing.Color.Red
            lblError.Text = "Amount Cannot be Greater than 1,000,000.00"
        Catch nre As NullRateException
            lblError.ForeColor = Drawing.Color.Red
            lblError.Text = "Rate is Required"
        Catch nnre As NonNumericRateException
            lblError.ForeColor = Drawing.Color.Red
            lblError.Text = "Rate Must be Numeric"
        Catch ire As InvalidRateException
            lblError.ForeColor = Drawing.Color.Red
            lblError.Text = "Rate Cannot be Greater than 1.00"
        Catch nte As NullTermException
            lblError.ForeColor = Drawing.Color.Red
            lblError.Text = "Term is Required"
        Catch nnte As NonNumericTermException
            lblError.ForeColor = Drawing.Color.Red
            lblError.Text = "Term Must be Numeric"
        Catch ite As InvalidTermException
            lblError.ForeColor = Drawing.Color.Red
            lblError.Text = "Term Cannot be Greater than 100.00"
        Catch ex As Exception
            lblError.ForeColor = Drawing.Color.Red
            lblError.Text = "Cheap Loans has encountered an error"
        End Try

        'Try
        '    validAmt = Double.TryParse(txtAmount.Text.ToString(), amt)
        'Catch ex As Exception
        '    lblError.Text = "Loan Amount is Invalid."
        'End Try
        'Try
        '    validRate = Double.TryParse(txtRate.Text.ToString(), rate)
        'Catch ex As Exception
        '    lblError.Text = "Annual Interest Rate is Invalid."
        'End Try
        'Try
        '    validTerm = Double.TryParse(txtTerm.Text.ToString(), term)
        'Catch ex As Exception
        '    lblError.Text = "Loan Term is Invalid."
        'End Try
    End Sub

    Private Function calcPmt(value As Loan) As Double
        Dim thePmt As Double

        thePmt = -Financial.Pmt(value.RateNum / 12, value.TermNum * 12, value.AmtNum)

        Return thePmt
    End Function
End Class
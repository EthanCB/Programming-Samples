﻿'Class:                 Loan.vb
'Company:               Cheap Loans
'Created/Revised By:    Ethan Bono
'Developed:             12/12/2017

Option Explicit On
Option Strict On
Option Infer Off

<Serializable>
Public Class Loan

    Private _name As String
    Private _amt As Double
    Private _rate As Double
    Private _term As Double

    Public Sub New()
        Name = "Ethan Bono"
        AmtStr = "2500.50"
        RateStr = ".65"
        TermStr = "5"
    End Sub

    Public Sub New(newName As String, newAmt As String, newRate As String, newTerm As String)
        Name = newName
        AmtStr = newAmt
        RateStr = newRate
        TermStr = newTerm
    End Sub

    Public Property Name As String
        Get
            Return _name
        End Get
        Set(value As String)
            If value.Trim = "" Then
                Throw (New NullNameException("Name cannot be null"))
            Else
                If value.Trim.Length() > 25 Then
                    Throw (New InvalidNameException("Name cannot have more than 25 characters"))
                Else
                    _name = value
                End If

            End If
        End Set
    End Property

    Public Property AmtStr As String
        Get
            Return _amt.ToString()
        End Get
        Set(value As String)
            If value.Trim = "" Then
                Throw (New NullAmtException("Amount cannot be null"))
            Else
                If Not Double.TryParse(value, _amt) Then
                    Throw (New NonNumericAmtException("Amount must be numeric."))
                Else
                    If _amt > 1000000 Or _amt < 1 Then
                        Throw (New InvalidAmtException("Amount must be between 1 and 1,000,000"))
                    End If
                End If
            End If
        End Set
    End Property

    Public Property RateStr As String
        Get
            Return _rate.ToString()
        End Get
        Set(value As String)
            If value.Trim = "" Then
                Throw (New NullRateException("Rate cannot be null"))
            Else
                If Not Double.TryParse(value, _rate) Then
                    Throw (New NonNumericRateException("Rate must be numeric."))
                Else
                    If _rate > 1 Or _rate < 0 Then
                        Throw (New InvalidRateException("Rate must be between 0 and 1"))
                    End If
                End If
            End If
        End Set
    End Property

    Public Property TermStr As String
        Get
            Return _term.ToString()
        End Get
        Set(value As String)
            If value.Trim = "" Then
                Throw (New NullTermException("Term cannot be null"))
            Else
                If Not Double.TryParse(value, _term) Then
                    Throw (New NonNumericTermException("Term must be numeric."))
                Else
                    If _term > 100 Or _term < 1 Then
                        Throw (New InvalidTermException("Term must be between 1 and 100"))
                    End If
                End If
            End If
        End Set
    End Property

    Public ReadOnly Property AmtNum As Double
        Get
            Return _amt
        End Get
    End Property

    Public ReadOnly Property RateNum As Double
        Get
            Return _rate
        End Get
    End Property

    Public ReadOnly Property TermNum As Double
        Get
            Return _term
        End Get
    End Property

    Public Function CalcPayment() As Double
        Dim payment As Double = 0

        Return payment
    End Function
End Class

Public Class NullNameException
    Inherits System.ApplicationException

    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub
End Class

Public Class NullAmtException
    Inherits System.ApplicationException

    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub
End Class

Public Class InvalidNameException
    Inherits System.ApplicationException

    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub
End Class

Public Class NonNumericAmtException
    Inherits System.ApplicationException

    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub
End Class

Public Class InvalidAmtException
    Inherits System.ApplicationException

    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub
End Class

Public Class NullRateException
    Inherits System.ApplicationException

    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub
End Class

Public Class NonNumericRateException
    Inherits System.ApplicationException

    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub
End Class

Public Class InvalidRateException
    Inherits System.ApplicationException

    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub
End Class

Public Class NullTermException
    Inherits System.ApplicationException

    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub
End Class

Public Class NonNumericTermException
    Inherits System.ApplicationException

    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub
End Class

Public Class InvalidTermException
    Inherits System.ApplicationException

    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub
End Class

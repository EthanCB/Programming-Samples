import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class BMIGUI extends JFrame implements ActionListener,
												ItemListener,
												ChangeListener{
	
	Container contentPane;
	JPanel pnlRadio;
	ButtonGroup group;
	
	JLabel lblWeight, lblHeight, lblBMI, lblStatus;
	JSlider sldHeight, sldWeight;
	JRadioButton radMetricUnit, radStandardUnit;
	JTextField txtHeight, txtWeight, txtBMI, txtStatus;
	JButton btnOK, btnClear;
	
	
	BMIGUI(){	
		DecimalFormat df = new DecimalFormat("###.00");
		this.setVisible(true);
		this.setSize(600,450);
		this.setLocation(650,200);
		this.setTitle("BMI Calculator");
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		contentPane = this.getContentPane();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setLayout(null);
			
//Instantiating radio buttons
		radMetricUnit = new JRadioButton("Metric");
		radStandardUnit = new JRadioButton("Standard");
		radMetricUnit.addItemListener(this);
		radStandardUnit.addItemListener(this);
		
//Instantiating button group
		group = new ButtonGroup();
		group.add(radMetricUnit);
		group.add(radStandardUnit);
		
//Instantiating panel
		pnlRadio = new JPanel();
		pnlRadio.setBorder(BorderFactory.createTitledBorder("Metric/Standard Input:"));
		
		pnlRadio.add(radMetricUnit);
		pnlRadio.add(radStandardUnit);
		contentPane.add(pnlRadio);
		pnlRadio.setLocation(135,25);
		pnlRadio.setSize(315, 50);
		
		radMetricUnit.setSelected(true);
		
//Instantiating labels
		lblHeight = new JLabel("Please enter your height:");
		lblHeight.setLocation(100, 100);
		lblHeight.setSize(150, 15);
		contentPane.add(lblHeight);
		
		lblWeight = new JLabel("Please enter your weight.");
		lblWeight.setLocation(340, 100);
		lblWeight.setSize(150, 15);
		contentPane.add(lblWeight);
		
		lblBMI = new JLabel("BMI: ");
		lblBMI.setLocation(210,305);
		lblBMI.setSize(75,25);
		contentPane.add(lblBMI);
		
		lblStatus = new JLabel("Status: ");
		lblStatus.setLocation(210,340);
		lblStatus.setSize(75,25);
		contentPane.add(lblStatus);
		
//Instantiating sliders
		sldHeight = new JSlider();
		sldHeight.setOrientation(JSlider.VERTICAL);
		sldHeight.setPaintLabels(true);
		sldHeight.setPaintTicks(true);
		sldHeight.setMinimum(0);
		sldHeight.setMaximum(200);
		sldHeight.setValue(150);
		sldHeight.setMajorTickSpacing(50);
		sldHeight.setMinorTickSpacing(10);
		contentPane.add(sldHeight);
		sldHeight.setSize(75,120);
		sldHeight.setLocation(135, 125);
		sldHeight.addChangeListener(this);
		
		sldWeight = new JSlider();
		sldWeight.setOrientation(JSlider.VERTICAL);
		sldWeight.setPaintLabels(true);
		sldWeight.setPaintTicks(true);
		sldWeight.setMinimum(0);
		sldWeight.setMaximum(100);
		sldWeight.setValue(70);
		sldWeight.setMajorTickSpacing(25);
		sldWeight.setMinorTickSpacing(5);
		contentPane.add(sldWeight);
		sldWeight.setSize(75,120);
		sldWeight.setLocation(375, 125);
		sldWeight.addChangeListener(this);
		
//Instantiating text fields
		txtHeight = new JTextField();
		txtHeight.setLocation(135, 270);
		txtHeight.setSize(75,25);
		txtHeight.setText(df.format(sldHeight.getValue()));
		contentPane.add(txtHeight);
		
		txtWeight = new JTextField();
		txtWeight.setLocation(375, 270);
		txtWeight.setSize(75,25);
		txtWeight.setText(df.format(sldWeight.getValue()));
		contentPane.add(txtWeight);
		
		txtBMI = new JTextField();
		txtBMI.setEditable(false);
		txtBMI.setLocation(275,305);
		txtBMI.setSize(75,25);
		contentPane.add(txtBMI);
				
		txtStatus = new JTextField();
		txtStatus.setEditable(false);
		txtStatus.setLocation(275,340);
		txtStatus.setSize(75,25);
		contentPane.add(txtStatus);
		
//Instantiating buttons
		btnOK = new JButton("OK");
		btnOK.setVisible(true);
		btnOK.setLocation(210, 375);
		btnOK.setSize(75,25);
		contentPane.add(btnOK);
		
		btnClear = new JButton("Clear");
		btnClear.setVisible(true);
		btnClear.setLocation(300, 375);
		btnClear.setSize(75,25);
		contentPane.add(btnClear);
		
		btnOK.addActionListener(this);
		btnClear.addActionListener(this);
		
		contentPane.repaint();
	}
	public static void main(String[] args){
		BMIGUI myFrame = new BMIGUI();
		
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		DecimalFormat dfInput = new DecimalFormat("###.00");
				
		BMICalculator myBMI;		
		
//Getting action source
		Object sourceObject = e.getSource();
		
//Error array
		String [] errMsg = {"Invalid weight.", "Invalid height.",
							"Height must be greater than zero", 
							"Weight must be greater than zero"};
		boolean valid;
		
//Instantiating BMICalculator class
		myBMI = new BMICalculator();
		
//Checking for btnOK action
		if(sourceObject == btnOK){
			valid = true;
			if (radMetricUnit.isSelected()){
//Validating metric input
				try{
					myBMI.setHeight(Double.parseDouble(txtHeight.getText()));
				}
				catch(NumberFormatException e1){
					JOptionPane.showMessageDialog(null, errMsg[1]);
					valid = false;
				}
				try{
					myBMI.setWeight(Double.parseDouble(txtWeight.getText()));
				}
				catch(NumberFormatException e1){
					JOptionPane.showMessageDialog(null, errMsg[0]);
					valid = false;
				}
			}
			else{
//Validating standard input
				try{
					myBMI.setInches(Double.parseDouble(txtHeight.getText()));
				}
				catch(NumberFormatException e1){
					JOptionPane.showMessageDialog(null, errMsg[1]);
					valid = false;
				}
				try{
					myBMI.setPounds(Double.parseDouble(txtWeight.getText()));
				}
				catch(NumberFormatException e1){
					JOptionPane.showMessageDialog(null, errMsg[0]);
					valid = false;
				}
			}
//Checking that input is greater than zero
			if(myBMI.getHeight()<=0){
				JOptionPane.showMessageDialog(null, errMsg[2]);
				valid = false;
			}
			if(myBMI.getWeight()<=0){
				JOptionPane.showMessageDialog(null, errMsg[3]);
				valid = false;
			}
//Calculating and formatting valid BMI
			if(valid){
				DecimalFormat df = new DecimalFormat("###.000");
				txtBMI.setText(df.format(myBMI.getBMI()));
				txtStatus.setText(myBMI.getStatus());
			}
			
			
		}
//Checking for btnClear action
		if(sourceObject == btnClear){
				txtBMI.setText("");
				txtStatus.setText("");
				txtWeight.setText(dfInput.format(sldWeight.getValue()));
				txtHeight.setText(dfInput.format(sldHeight.getValue()));
		}
	}
	@Override
	public void itemStateChanged(ItemEvent e) {
//Getting itemStateChanged source
		JRadioButton source = (JRadioButton) e.getSource();
		
//Checking selected radio button
		if(e.getStateChange() == ItemEvent.SELECTED){
			if(source.equals(radStandardUnit)){
				
				sldHeight.setMinimum(0);
				sldHeight.setMaximum(100);
				sldHeight.setValue(70);
				sldHeight.setMajorTickSpacing(25);
				sldHeight.setMinorTickSpacing(5);
				
				sldWeight.setMinimum(0);
				sldWeight.setMaximum(200);
				sldWeight.setValue(150);
				sldWeight.setMajorTickSpacing(50);
				sldWeight.setMinorTickSpacing(10);
				contentPane.repaint();
			}
		}
		else{
			if(source.equals(radStandardUnit)){
				sldHeight.setMinimum(0);
				sldHeight.setMaximum(200);
				sldHeight.setValue(150);
				sldHeight.setMajorTickSpacing(50);
				sldHeight.setMinorTickSpacing(10);
					
				sldWeight.setMinimum(0);
				sldWeight.setMaximum(100);
				sldWeight.setValue(70);
				sldWeight.setMajorTickSpacing(25);
				sldWeight.setMinorTickSpacing(5);
			}			
		}	
		contentPane.repaint();
	}
	@Override
	public void stateChanged(ChangeEvent e) {
		DecimalFormat df = new DecimalFormat("###.00");
		
//Getting stateChanged source
		JSlider source = (JSlider) e.getSource();
		
//Outputting height slider value
		if(source.equals(sldHeight)){
			txtHeight.setText(df.format(sldHeight.getValue()));
		}
		
//Outputting weight slider value
		if(source.equals(sldWeight)){
			txtWeight.setText(df.format(sldWeight.getValue()));
		}
		contentPane.repaint();
	}	
}

/**
 * The BMICalculator class will take input from the user, convert to
 * metric units, then calculate the user's BMI and displays whether
 * its high, normal, or low
 * 
 * @author Ethan Bono
 *
 * Created 3/12/2017
 */
public class BMICalculator {
	/**
	 * The weight of the user in kilograms
	 */
	private double iWeight;
	/**
	 * The height of the user in centimeters
	 */
	private double iHeight;
	
	/**
	 * Constructor using fields
	 * @param iWeight
	 * @param iHeight
	 */
	public BMICalculator(Double iWeight, Double iHeight) {
		super();
		this.iWeight = iWeight;
		this.iHeight= iHeight;
	}
	
	/**
	 * Default constructor
	 */
	public BMICalculator() {
		this.iWeight = 70.0;
		this.iHeight = 150.0;
	}
	
	public void setWeight(Double iWeight) {
		this.iWeight = iWeight;
	}
	public Double getWeight() {
		return iWeight;
	}
	public void setHeight(Double iHeight) {
		this.iHeight = iHeight;
	}
	public Double getHeight() {
		return iHeight;
	}
	/**
	 * Converts weight from pounds to kilograms
	 * @param iWeight
	 */
	public void setPounds(Double iWeight) {
		double kgConversion=2.2046;
		
		this.iWeight = iWeight / kgConversion;
	}
	/**
	 * Converts height from inches to centimeters
	 * @param iHeight
	 */
	public void setInches(Double iHeight) {
		double cmConversion=2.54;		
		
		this.iHeight = iHeight * cmConversion;
	}
	/**
	 * Takes input weight and height and calculates BMI
	 * @return
	 */
	public Double getBMI() {
		
		Double BMI;
		
		BMI = iWeight / Math.pow((iHeight/100.0), 2);
		
		return BMI;
	}
	/**
	 * Determines the whether your BMI is low, normal, or high
	 * @return
	 */
	public String getStatus() {
		String oStatus;
				
		String [] status = {"Low", "Normal", "High"};
				
		if(getBMI() < 20){
			oStatus = status[0]; 
		}//End of iff
		else{
			if(getBMI() > 25){
				oStatus = status[2];
			}//End of if
			else{
				oStatus = status[1];
			}//End of else
		}//End of else
		
		return oStatus;
	}
	/**
	 * Prints the input height and weight, the calculated BMI, and the status
	 */
	@Override
	public String toString() {
		return "Your height is " + iHeight + " and your weight is " + iWeight + "\n" + 
				"Your BMI is: " + getBMI() + "\n" + getStatus();
	}
}
